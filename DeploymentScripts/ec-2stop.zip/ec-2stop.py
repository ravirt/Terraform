import boto3
import datetime
from datetime import timedelta
from datetime import datetime, date, time
from datetime import tzinfo

region = 'us-east-1'
ec2 = boto3.resource('ec2')
instances = ec2.instances.filter(
    Filters=[{'Name': 'instance-state-name', 'Values': ['running']}])
for instance in instances:
    print('instance.id', 'instance.instance_type')
def test(event, context):
    client = boto3.client('cloudwatch')
    response = client.get_metric_statistics(
    Namespace='AWS/EC2',
    MetricName='CPUUtilization',
    Dimensions=[
        {
            'Name': 'InstanceId',
            'Value': 'i-0a63dbd22a8278b5b'
        },
    ],
    StartTime=datetime.now() - timedelta(hours=0.45),
    EndTime=datetime.now(),
    Period=960,
    Statistics=[
        'Maximum',
    ])

    CPU_Utilization=response['Datapoints'][0]['Maximum']
    
    if(CPU_Utilization<1):
        print('stopinstance')
    else:
        print('donothing')


